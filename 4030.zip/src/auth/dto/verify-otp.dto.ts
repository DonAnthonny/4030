// src/auth/dto/verify-otp.dto.ts
import { IsPhoneNumber, IsString, IsOptional, Matches } from 'class-validator';

export class VerifyOtpDto {
  @IsPhoneNumber('IR')
  phone: string;

  @IsString()
  otp: string;

  @IsOptional()
  firstName?: string;

  @IsOptional()
  lastName?: string;

  @IsOptional()
  @Matches(/^\d{10}$/, { message: 'کد ملی باید 10 رقم باشد.' })
  nationalCode?: string;

  @IsOptional()
  @Matches(/^\d{4}\/\d{2}\/\d{2}$/, { message: 'تاریخ تولد باید در قالب YYYY/MM/DD باشد.' })
  birthday?: string;

  @IsOptional()
  referralCode?: string;
}
