import { IsEnum, IsString, IsNotEmpty, Length } from 'class-validator';
import { DriverType } from '../enums/driver-type.enum';

export class CreateDriverDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  lastname: string;

  @IsString()
  @Length(10, 10)
  nationalCode: string;

  @IsString()
  licenceNumber: string;

  @IsString()
  fatherName: string;

  @IsString()
  birthday: string;

  @IsEnum(DriverType)
  type: DriverType;
}
