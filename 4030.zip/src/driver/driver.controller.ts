import { Controller } from '@nestjs/common';

@Controller('driver')
export class DriverController {}
